# Login-Register---MERN-Stack-MongoDB-express-React-js-Nodejs---2022
Login &amp; Register - MERN Stack ( MongoDB, express, React js, Nodejs ) - 2022


<!-- import logo from './logo.svg';
import './App.css';
import Home from './Component/Home';
import { Login } from './Component/Login';
import Register from './Component/Register';

import Team from './Component/Team';
import TeamRoaster from './Component/TeamRoaster';
import UserStory from './Component/UserStory';
import Task from './Component/Task';
import "./Component/style.css"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import data from './ContextApi';
import { useState } from 'react';
import ProjectForm from './Component/ProjectForm';

function App() {
  const [userdata,setUserData] = useState({})
  
  return (
    <div className="App">
      <data.Provider value={{userdata,setUserData}}>
        <Router>
          <Routes>
            <Route path="/"
              element={userdata && userdata._id ? <Home /> : <Login/>}
            />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/projects" element={<ProjectForm />} />
            <Route path="/teams" element={<Team />} />
            <Route path="/teamRoasters" element={<TeamRoaster />} />
            <Route path="/userStories" element={<UserStory />} />
            <Route path="/tasks" element={<Task />} />
          </Routes>
        </Router>
      </data.Provider>

    </div>
  );
}

export default App; -->
