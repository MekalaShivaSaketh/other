import { createContext } from "react";

const data = createContext(null)

export default data